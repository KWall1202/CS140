package lab03;

import java.util.Arrays;
import static lab03.ArrayPractice.*;

public class ArrayPracticeTester {
    public static void test(String expected, int[] actual) {
        System.out.println("Expected: " + expected +
                           ", received: " + Arrays.toString(actual));
    }

    public static void test(int[] expected, int[] actual) {
        System.out.println("Expected: " + Arrays.toString(expected) +
                           ", received: " + Arrays.toString(actual));
    }
    
    public static void test(double expected, double actual) {
        System.out.println("Expected: " + expected + ", received: " + actual);
    }


    public static void test(boolean expected, boolean actual) {
        System.out.println("Expected: " + expected + ", received: " + actual);
    }


    public static void main(String[] args) {
        int[] simple = {1, 2, 3, 4, 5};
        int[] reversed = {5, 4, 3, 2, 1};
        int[] longArray = {6, 5, 4, 3, 2, 1};
        int[] higherValues = {5, 6, 7, 8};
        int[] shortArray = {1, 2, 3};
        int[] singleValue = {6};
        int[] repeatingValues = {1, 2, 3, 3, 3, 4};
        int[] nullArray = null;
        int[] empty = new int[0];
        test(reversed, reverse(simple));
        test(simple, reverse(reversed));
        test("[1, 2, 3, 4, 5, 6]", reverse(longArray));
        test("null", reverse(nullArray));
        test("[]", reverse(empty));
        
        test(true, isIncreasing(simple));
        test(false, isIncreasing(reversed));
        test(true, isIncreasing(nullArray));
        test(true, isIncreasing(empty));
        test(true, isIncreasing(singleValue));
        test(false, isIncreasing(repeatingValues));
    
        test(3, average(simple));
        test(3, average(reversed));
        try {
            average(nullArray);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        test(0, average(empty));

        test("[1, 3, 5]", evenIndicesOnly(simple));
        test("[5, 3, 1]", evenIndicesOnly(reversed));
        test("[]", evenIndicesOnly(empty));
        test("null", evenIndicesOnly(nullArray));
                
        int[] reversedSimple = {1, 2, 3, 4, 5};
        reverseInPlace(reversedSimple);
        test("[5, 4, 3, 2, 1]", reversedSimple);
        int[] reversedLongArray = {6, 5, 4, 3, 2, 1};
        reverseInPlace(reversedLongArray);
        test("[1, 2, 3, 4, 5, 6]", reversedLongArray);
        int[] reversedReversed = {5, 4 ,3, 2, 1};
        reverseInPlace(reversedReversed);
        test("[1, 2, 3, 4, 5]", reversedReversed);
        int[] reversedNull = null;
        reverseInPlace(reversedNull);
        test("null", reversedNull);
        int[] reversedEmpty = new int[0];
        reverseInPlace(reversedEmpty);
        test("[]", reversedEmpty);

        try {
            concatenate(null, null);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        try {
            concatenate(simple, null);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        try {
            concatenate(null, simple);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        test("[1, 2, 3, 4, 5]", concatenate(empty, simple));
        test("[1, 2, 3, 4, 5]", concatenate(simple, empty));
        test("[]", concatenate(empty, empty));
        test("[1, 2, 3, 5, 6, 7, 8]", concatenate(shortArray, higherValues));
        
        try {
            endToEnd(null, null);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        try {
            endToEnd(simple, null);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        try {
            endToEnd(null, simple);
            System.out.println("test failed - exception not thrown");
        } catch(IllegalArgumentException e) {
            System.out.println("caught the expected illegal argument exception");
        }
        test("[5, 4, 3, 2, 1]", endToEnd(empty, simple));
        test("[1, 2, 3, 4, 5]", endToEnd(simple, empty));
        test("[]", endToEnd(empty, empty));
        test("[1, 2, 3, 8, 7, 6, 5]", endToEnd(shortArray, higherValues));

        

    }

}
