package exam01;

public class Pair {
    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Pair(int aX, int aY) {
        x = aX;
        y = aY;
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
