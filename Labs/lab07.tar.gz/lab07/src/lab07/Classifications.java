package lab07;

public interface Classifications {
	String kingdom();
	String genus();
	String species();
}
