package project;

public class IllegalInstructionException extends RuntimeException {
	public IllegalInstructionException(String message) {
		super(message);
	}
	
}
