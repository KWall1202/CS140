package lab04; 

public class Student {
    private int id;
    private String name;

    public Student(int aId, String aName) {
        id = aId;
        name = aName;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
